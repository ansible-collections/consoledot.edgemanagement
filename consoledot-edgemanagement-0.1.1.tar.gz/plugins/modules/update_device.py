#!/usr/bin/python
# -*- coding: utf-8 -*-

# (c) 2022, Adam Miller (admiller@redhat.com)
# MIT License (see LICENSE or https://opensource.org/licenses/MIT)

from __future__ import absolute_import, division, print_function

__metaclass__ = type

DOCUMENTATION = """
---
module: create_image
short_description: Create a new RHEL for Edge Image on console.redhat.com
description:
  - This module will build a RHEL for Edge Image on console.redhat.com
version_added: "0.1.0"
options:
  name:
    description:
      - RHC Client ID of device to upgrade
    required: true
    type: str
  imageset_id:
    description:
      - Id of ImageSet to use for the device upgrade
    required: true
    type: str
author: Adam Miller @maxamillion
"""


# FIXME - provide correct example here
RETURN = """
"""

EXAMPLES = """
- name: Get ImageSet Info for named image "WesternRegionTerminalPOS"
  consoledot.edgemanagement.imagesets_info:
    name: "WesternRegionTerminalPOS"
  register: imageinfo_output

- name: Upgrade device 2ae43de4-bce7-4cfb-9039-af77458260ea with latest WesternRegionTerminalPOS image
  consoledot.edgemanagement.update_device:
    client_id: "2ae43de4-bce7-4cfb-9039-af77458260ea"
    imageset_id: "{{ imageinfo_output['id'] }} "
  register: updatedevice_output

- name: debugging output of the updatedevice_output registered variable
  debug:
    var: updatedevice_output
"""

from ansible.module_utils.basic import AnsibleModule
from ansible.module_utils._text import to_text

from ansible.module_utils.six.moves.urllib.parse import quote
from ansible_collections.consoledot.edgemanagement.plugins.module_utils.edgemanagement import (
    ConsoleDotRequest,
)

import copy
import json


def main():

    distro_choices = ["rhel-84", "rhel-85"]

    arch_choices = ["x86_64", "aarch64"]

    argspec = dict(
        name=dict(required=True, type="str"),
        imageset_id=dict(required=True, type="str"),
    )

    module = AnsibleModule(argument_spec=argspec, supports_check_mode=True)

    crc_request = ConsoleDotRequest(module)

    # FIXME - THIS MODULE IS NOT YET IMPLEMENTED

#    try:
#        response = crc_request.post("/api/edge/v1/updates/", data=json.dumps(postdata))
#        if response["Status"] not in [400, 403, 404]:
#            module.exit_json(
#                msg="Successfully queued image build", image=response, postdata=postdata
#            )
#        else:
#            module.fail_json(msg=response, postdata=postdata)
#
#    except Exception as e:
#        module.fail_json(msg=to_text(e), postdata=postdata)

    module.fail_json(msg="ERROR: Module not implemented")


if __name__ == "__main__":
    main()
